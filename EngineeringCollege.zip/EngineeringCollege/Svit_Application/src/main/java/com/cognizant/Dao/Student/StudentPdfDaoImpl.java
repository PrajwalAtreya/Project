package com.cognizant.Dao.Student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.StudentPdfSkell;
import com.cognizant.repository.StudentPdfRepository;

@Service
public class StudentPdfDaoImpl implements StudentPdfDao 
{
	@Autowired
	StudentPdfRepository studentPdfRepository;
	
	@Override
	public void uploadPdf(StudentPdfSkell studentPdfSkell) 
	{
		// TODO Auto-generated method stub
		studentPdfRepository.save(studentPdfSkell);
	}

	@Override
	public List<StudentPdfSkell> viewAllPdf() 
	{
		// TODO Auto-generated method stub
		List<StudentPdfSkell> studentPdfSkellList = studentPdfRepository.findAll();
		return studentPdfSkellList;
	}

}
