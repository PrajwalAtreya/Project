package com.cognizant.Dao.Admin;

import org.springframework.stereotype.Service;

import com.cognizant.model.AdminDetSkell;

@Service
public interface AdminDetDao 
{
	public AdminDetSkell validateAdmin(AdminDetSkell adminDetSkell);
}
