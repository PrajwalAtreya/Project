package com.cognizant.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;


@Entity
@Component
public class StudentPdfSkell 
{
	@Id
	private String studentUsn;
	private String studentName;
	private	String studentEmail;
	private Long studentPhNum;
	private Integer studentSem;
	private Integer studentTestNum;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date studentSubDate;
	@Lob 
	private byte[] studentFile;
	
	public StudentPdfSkell() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentPdfSkell(String studentUsn, String studentName, String studentEmail, Long studentPhNum,
			Integer studentSem, Integer studentTestNum, Date studentSubDate) {
		super();
		this.studentUsn = studentUsn;
		this.studentName = studentName;
		this.studentEmail = studentEmail;
		this.studentPhNum = studentPhNum;
		this.studentSem = studentSem;
		this.studentTestNum = studentTestNum;
		this.studentSubDate = studentSubDate;
	}
	
	public StudentPdfSkell(String studentUsn, String studentName, String studentEmail, Long studentPhNum,
			Integer studentSem, Integer studentTestNum, Date studentSubDate, byte[] studentFile) {
		super();
		this.studentUsn = studentUsn;
		this.studentName = studentName;
		this.studentEmail = studentEmail;
		this.studentPhNum = studentPhNum;
		this.studentSem = studentSem;
		this.studentTestNum = studentTestNum;
		this.studentSubDate = studentSubDate;
		this.studentFile = studentFile;
	}

	public String getStudentUsn() {
		return studentUsn;
	}

	public void setStudentUsn(String studentUsn) {
		this.studentUsn = studentUsn;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public Long getStudentPhNum() {
		return studentPhNum;
	}

	public void setStudentPhNum(Long studentPhNum) {
		this.studentPhNum = studentPhNum;
	}

	public Integer getStudentSem() {
		return studentSem;
	}

	public void setStudentSem(Integer studentSem) {
		this.studentSem = studentSem;
	}

	public Integer getStudentTestNum() {
		return studentTestNum;
	}

	public void setStudentTestNum(Integer studentTestNum) {
		this.studentTestNum = studentTestNum;
	}

	public Date getStudentSubDate() {
		return studentSubDate;
	}

	public void setStudentSubDate(Date studentSubDate) {
		this.studentSubDate = studentSubDate;
	}

	public byte[] getStudentFile() {
		return studentFile;
	}

	public void setStudentFile(byte[] studentFile) {
		this.studentFile = studentFile;
	}

	@Override
	public String toString() {
		return "StudentPdfSkell [studentUsn=" + studentUsn + ", studentName=" + studentName + ", studentEmail="
				+ studentEmail + ", studentPhNum=" + studentPhNum + ", studentSem=" + studentSem + ", studentTestNum="
				+ studentTestNum + ", studentSubDate=" + studentSubDate + ", studentFile=" + studentFile + "]";
	}
	
	
}
