package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.AdminDetSkell;

@Repository
public interface AdminDetRepository extends JpaRepository<AdminDetSkell, String> 
{
	@Query("select a from AdminDetSkell a where a.adminId=(:adminId) and a.adminPassword=(:adminPassword)")
	AdminDetSkell findByLoginData(String adminId, String adminPassword);
}
