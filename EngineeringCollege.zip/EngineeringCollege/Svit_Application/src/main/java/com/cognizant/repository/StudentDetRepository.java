package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.StudentDetSkell;

@Repository
public interface StudentDetRepository extends JpaRepository<StudentDetSkell, String>
{
	//@Query("Select s from StudentDetSkell s where s.studentUsn=(:studentUsn) and u.studentPassword=(:studentPassword)")
	//StudentDetSkell findByLoginData(String studentUsn,String studentPassword);
}
