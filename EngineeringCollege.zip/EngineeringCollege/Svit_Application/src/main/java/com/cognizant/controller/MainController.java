package com.cognizant.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.Dao.Staff.StaffDetDao;
import com.cognizant.Dao.Staff.StaffPortDao;
import com.cognizant.Dao.Student.StudentDetDao;
import com.cognizant.Dao.Student.StudentPdfDao;
import com.cognizant.Dao.Student.StudentPortDao;
import com.cognizant.model.AdminDetSkell;
import com.cognizant.model.StaffDetSkell;
import com.cognizant.model.StaffPortSkell;
import com.cognizant.model.StudentDetSkell;
import com.cognizant.model.StudentPdfSkell;
import com.cognizant.model.StudentPortSkell;

@Controller
public class MainController 
{	
	@RequestMapping("/")
	public String mainPage()
	{
		return "index";
	}
	
	
//-----------------------------------------StudentDetController-----------------------------------

	@Autowired
	AdminDetSkell adminDetSkell;
	
	
	
	@RequestMapping("/adminLogin")
	public String adminLogin(Model model)
	{
		model.addAttribute("adminDetSkell", adminDetSkell);
		model.addAttribute("msg", msg);
		return "adminLogin";
	}
	
	@RequestMapping("/adminHome")
	public String adminHome()
	{
		return "adminHome";
	}
	
	@RequestMapping("/adminStaffMod")
	public String adminStaffMod()
	{
		return "adminStaffMod";
	}
	
	@RequestMapping("/adminStudentMod")
	public String adminStudentMod()
	{
		return "adminStudentMod";
	}
	
//-----------------------------------------StudentDetController-----------------------------------
	@Autowired
	StudentDetSkell studentDetSkell;
	
	@Autowired
	StudentDetDao studentDetDao;
	
	String msg;
	
	
	
	
	/*@RequestMapping("studentHome")
	public String studentHome(Model model)
	{
		model.addAttribute("studentDetSkell", studentDetSkell);
		model.addAttribute("msg", msg);
		return "studentLogin";
	}*/
	
	@RequestMapping("studentRegistration")
	public String showStudentRegisterationForm(Model model) 
	{
		model.addAttribute("studentDetSkell", studentDetSkell);
		return "studentRegistration";
	}
	
		@RequestMapping("studentDetSubmitform")
		public ModelAndView saveStudent(@ModelAttribute("studentDetSkell") StudentDetSkell studentDetSkell, ModelAndView mv) 
		{
			studentDetDao.addStudent(studentDetSkell);
			mv.addObject("msg", "Student Added Successfully");
			mv.setViewName("staffHome");
			return mv;
		}
	
	@RequestMapping("viewAllStudents")
	public ModelAndView viewAllStudents(ModelAndView mv)
	{
		List<StudentDetSkell>studentDetSkellList = studentDetDao.getAllStudent();
		mv.addObject("studentDetSkell",studentDetSkellList);
		//mv.addObject("msg", msg);
		mv.setViewName("viewAllStudents");
		return mv;
	}
	
	@RequestMapping("viewToUpdate")
	public ModelAndView viewToUpdate(ModelAndView mv)
	{
		List<StudentDetSkell>studentDetSkellList = studentDetDao.getAllStudent();
		mv.addObject("studentDetSkell",studentDetSkellList);
		//mv.addObject("msg", msg);
		mv.setViewName("viewToUpdate");
		return mv;
	}
	
	@RequestMapping("updateStudentData/{studentUsn}")
	public String updateStudentData(@PathVariable String studentUsn, Model m)
	{
		StudentDetSkell studentDetSkell = studentDetDao.getStudentByUsn(studentUsn);
		m.addAttribute("studentDetSkell",studentDetSkell);
		return "updateStudentData";	
	}
	
	@RequestMapping("saveStudentData")
	public String saveStudentData(@ModelAttribute("studentDetSkell") StudentDetSkell studentDetSkell)
	{
		studentDetDao.updateStudentDet(studentDetSkell);
		return "redirect:/viewToUpdate";
	}
	
	@RequestMapping("deleteStudentData/{studentUsn}")
	public String deleteStudent(@PathVariable String studentUsn)
	{
		studentDetDao.deleteStudentDet(studentUsn);
		return "redirect:/viewToUpdate";
	}
	
//------------------------------------StudentPortController--------------------------------------
	@Autowired
	StudentPortSkell studentPortSkell;
	
	@Autowired
	StudentPortDao studentPortDao;
	
	@RequestMapping("studentHome")
	public String studentHome(Model model)
	{
		model.addAttribute("studentPortSkell", studentPortSkell);
		model.addAttribute("msg", msg);
		return "studentLogin";
	}
	
	@RequestMapping("validateStudent")
	public String studentRegistrartionForm(@ModelAttribute("studentPortSkell")StudentPortSkell studentPortSkell, Model m, HttpSession session)
	{
		StudentPortSkell studentPortSkell1 = studentPortDao.validateStudent(studentPortSkell);
		if(studentPortSkell1!=null)
		{
			msg = "Login Successful";
			session.setAttribute("studentPortSkell", studentPortSkell1.getStudentUsn());
			System.out.println("Login Successful");
			return "redirect:/pdfSubmissionPage";
		}
		else
		{
			msg = "Login Failed";
			System.out.println("Login Successful");
			return "redirect:/studentHome";
		}
		
	}
	
	@RequestMapping("studentPortalRegistration")
	public String studentPortRegisteration(Model m) 
	{
		m.addAttribute("studentPortSkell",studentPortSkell);
		return "studentPortalRegistration";
	}
	
	@RequestMapping("submitStudentPort")
	public String submitSudentPort(@ModelAttribute("studentPortSkell") StudentPortSkell studentPortSkell, Model m)
	{
		System.out.println("Registration in Progress...");
		studentPortDao.addStudentPort(studentPortSkell);
		m.addAttribute("msg", "Portal Data Registered Successfully");
		return "adminStudentMod";
	}
	
	@RequestMapping("viewToUpdateStudentPort")
	public ModelAndView viewToUpdateStudentPort(ModelAndView mv)
	{
		List<StudentPortSkell>studentPortSkellList = studentPortDao.getAllStudent();
		mv.addObject("studentPortSkell",studentPortSkellList);
		//mv.addObject("msg", msg);
		mv.setViewName("viewToUpdateStudentPort");
		return mv;
	}
	
	@RequestMapping("updateStudentPort/{studentUsn}")
	public String updateStudentPort(@PathVariable String studentUsn, Model m)
	{
		StudentPortSkell studentPortSkell = studentPortDao.getStudentByUsn(studentUsn);
		m.addAttribute("studentPortSkell",studentPortSkell);
		return "updateStudentPort";	
	}
	
	@RequestMapping("saveStudentPort")
	public String saveStudentPort(@ModelAttribute("studentPortSkell") StudentPortSkell studentPortSkell)
	{
		studentPortDao.updateStudentPort(studentPortSkell);
		return "redirect:/viewToUpdateStudentPort";
	}
	
	@RequestMapping("deleteStudentPort/{studentUsn}")
	public String deleteStudentPort(@PathVariable String studentUsn)
	{
		studentPortDao.deleteStudentPort(studentUsn);
		return "redirect:/viewToUpdateStudentPort";
	}
	
//------------------------------------StudentPdfController------------------------------------
	
	@Autowired
	StudentPdfSkell studentPdfSkell;
	
	@Autowired
	StudentPdfDao studentPdfDao; 
 	
	@RequestMapping("pdfSubmissionPage")
	public String pdfSubmission(Model model) 
	{
		model.addAttribute("studentPdfSkell", studentPdfSkell);
		return "studentPdfSub";
	}
	
	@RequestMapping("submitPdf")
	public ModelAndView submitPdf(@ModelAttribute("studentPdfSkell") StudentPdfSkell studentPdfSkell, ModelAndView mv, @RequestParam("pic") MultipartFile file) throws IOException
	{
		System.out.println("Uploading Your File...");
		byte[] studentFile = file.getBytes();
		studentPdfSkell.setStudentFile(studentFile);
		studentPdfDao.uploadPdf(studentPdfSkell);
		mv.addObject("msg", "File Submitted Successfully");
		mv.setViewName("postPdfSub");
		return mv;
	}
	
	@RequestMapping("postPdfSub")
	public String postPdfSub()
	{
		return "postPdfSub";
	}
	
	@RequestMapping("viewAllPdf")
	public ModelAndView viewAllPdf(ModelAndView mv)
	{
		List<StudentPdfSkell> studentPdfSkellList = studentPdfDao.viewAllPdf();
		mv.addObject("studentPdfSkell",studentPdfSkellList);
		mv.setViewName("viewAllPdf");
		return mv;
	}
	
	@RequestMapping("viewAllPdfStaff")
	public ModelAndView viewAllPdfStaff(ModelAndView mv)
	{
		List<StudentPdfSkell> studentPdfSkellList = studentPdfDao.viewAllPdf();
		mv.addObject("studentPdfSkell",studentPdfSkellList);
		mv.setViewName("viewAllPdfStaff");
		return mv;
	}
	
//------------------------------------StaffDetController--------------------------------------
	@Autowired
	StaffDetSkell staffDetSkell;
	
	@Autowired
	StaffDetDao staffDetDao;
	
	
	/*@RequestMapping("staffLogin")
	public String staffhome(Model model)
	{
		model.addAttribute("staffDetSkell", staffDetSkell);
		model.addAttribute("msg", msg);
		return "staffLogin";
	}*/
	
	@RequestMapping("/staffHome")
	public String staffhome()
	{
		return "staffHome";
	}
	
	@RequestMapping("staffRegistration")
	public String StaffRegisterationForm(Model model) 
	{
		model.addAttribute("staffDetSkell", staffDetSkell);
		return "staffRegistration";
	}
	
	@RequestMapping("staffDetSubmitform")
	public ModelAndView saveStaff(@ModelAttribute("staffDetSkell") StaffDetSkell staffDetSkell, ModelAndView mv) 
	{
		staffDetDao.addStaff(staffDetSkell);
		mv.addObject("msg", "Staff Added Successfully");
		mv.setViewName("adminStaffMod");
		return mv;
	}
	
	@RequestMapping("viewToUpdateStaffDetNewFile")
	public ModelAndView getAllStaff(ModelAndView mv)
	{
		List<StaffDetSkell>staffDetSkellList = staffDetDao.getAllStaff();
		mv.addObject("staffDetSkell",staffDetSkellList);
		mv.addObject("msg", msg);
		mv.setViewName("viewToUpdateStaffDetNewFile");
		return mv;
	}
	@RequestMapping("updateStaffDet/{staffId}")
	public String updateStaffDet(@PathVariable String staffId, Model m)
	{
		StaffDetSkell staffDetSkell = staffDetDao.getStaffById(staffId);
		m.addAttribute("staffDetSkell", staffDetSkell);
		return "updateStaffDet";
		
	}
	
	@RequestMapping("saveStaffDet")
	public String saveStaffDet(@ModelAttribute("staffDetSkell") StaffDetSkell staffDetSkell)
	{
		staffDetDao.updateStaffDet(staffDetSkell);
		return "redirect:/viewToUpdateStaffDetNewFile";
	}
	
	@RequestMapping("deleteStaffDet/{staffId}")
	public String deleteStaffDet(@PathVariable String staffId)
	{
		staffDetDao.deleteStaffDet(staffId);
		return "redirect:/viewToUpdateStaffDetNewFile";
	}
	
	@RequestMapping("viewAllStaff")
	public ModelAndView viewAllStaff(ModelAndView mv)
	{
		List<StaffDetSkell> staffDetSkellList =  staffDetDao.getAllStaff();
		mv.addObject("staffDetSkell",staffDetSkellList);
		mv.setViewName("viewAllStaff");
		return mv;
	}


//------------------------------------StaffPortController--------------------------------------
	
	@Autowired 
	StaffPortSkell staffPortSkell;
	
	@Autowired
	StaffPortDao staffPortDao;
	
	@RequestMapping("staffLogin")
	public String staffLogin(Model model)
	{
		model.addAttribute("staffPortSkell", staffPortSkell);
		model.addAttribute("msg", msg);
		return "staffLogin";
	}
	
	@RequestMapping("staffPortRegistration")
	public String staffPortRegisteration(Model model) 
	{
		model.addAttribute("staffPortSkell", staffPortSkell);
		return "staffPortalRegistration";
	}
	
	@RequestMapping("submitStaffPort")
	public String submitStaffPort(@ModelAttribute("staffPortSkell") StaffPortSkell staffPortSkell, Model m)
	{
		System.out.println("Registering Your...");
		staffPortDao.addStaffPort(staffPortSkell);
		m.addAttribute("msg", "Portal Data Registered Successfully");
		return "adminStaffMod";
	}
	
	@RequestMapping("viewToUpdateStaffPort")
	public ModelAndView viewToUpdateStaffPort(ModelAndView mv)
	{
		List<StaffPortSkell>staffPortSkellList = staffPortDao.getAllStaff();
		mv.addObject("staffPortSkell",staffPortSkellList);
		//mv.addObject("msg", msg);
		mv.setViewName("viewToUpdateStaffPort");
		return mv;
	}
	
	@RequestMapping("updateStaffPort/{staffId}")
	public String updateStaffPort(@PathVariable String staffId, Model m)
	{
		StaffPortSkell staffPortSkell = staffPortDao.getStaffById(staffId);
		m.addAttribute("staffPortSkell",staffPortSkell);
		return "updateStaffPort";	
	}
	
	@RequestMapping("saveStaffPort")
	public String saveStaffPort(@ModelAttribute("staffPortSkell") StaffPortSkell staffPortSkell)
	{
		staffPortDao.updateStaffPort(staffPortSkell);
		return "redirect:/viewToUpdateStaffPort";
	}
	
	@RequestMapping("deleteStaffPort/{staffId}")
	public String deleteStaffPort(@PathVariable String staffId)
	{
		staffPortDao.deleteStaffPort(staffId);
		return "redirect:/viewToUpdateStaffPort";
	}
}