package com.cognizant.Dao.Student;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.StudentDetSkell;
import com.cognizant.model.StudentPortSkell;

@Service
public interface StudentPortDao 
{
	public List<StudentPortSkell> getAllStudent();
	public StudentPortSkell getStudentByUsn(String studentUsn);
	public void addStudentPort(StudentPortSkell studentPortSkell);
	public void updateStudentPort(StudentPortSkell studentPortSkell);
	public StudentPortSkell validateStudent(StudentPortSkell studentPortSkell);
	public void deleteStudentPort(String studentUsn);
}