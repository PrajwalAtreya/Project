package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="AdminDetails")
@Component
public class AdminDetSkell 
{
	@Id
	private String adminId;
	private String adminName;
	private String adminEmail;
	private Double adminPhNum;
	private String adminPassword;
	
	public AdminDetSkell() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminDetSkell(String adminId, String adminName, String adminEmail, Double adminPhNum,
			String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminEmail = adminEmail;
		this.adminPhNum = adminPhNum;
		this.adminPassword = adminPassword;
	}

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public Double getAdminPhNum() {
		return adminPhNum;
	}

	public void setAdminPhNum(Double adminPhNum) {
		this.adminPhNum = adminPhNum;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	@Override
	public String toString() {
		return "AdminDetSkell [adminId=" + adminId + ", adminName=" + adminName + ", adminEmail=" + adminEmail
				+ ", adminPhNum=" + adminPhNum + ", adminPassword=" + adminPassword + "]";
	}
	
}
