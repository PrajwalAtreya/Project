package com.cognizant.Dao.Staff;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.StaffDetSkell;

@Service
public interface StaffDetDao 
{
	public void addStaff(StaffDetSkell staffDetSkell);
	public StaffDetSkell getStaffById(String staffId);
	public void updateStaffDet(StaffDetSkell staffDetSkell);
	public List<StaffDetSkell> getAllStaff();
	public void deleteStaffDet(String staffId);
}
