package com.cognizant.Dao.Student;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.StudentPdfSkell;

@Service
public interface StudentPdfDao 
{
	public void uploadPdf(StudentPdfSkell studentPdfSkell);
	public List<StudentPdfSkell> viewAllPdf();
}
