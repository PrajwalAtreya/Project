package com.cognizant.Dao.Staff;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.StaffDetSkell;
import com.cognizant.repository.StaffDetRepository;

@Service
public class StaffDetDaoImpl implements StaffDetDao 
{
	@Autowired
	StaffDetRepository staffDetRepository;

	@Override
	public void addStaff(StaffDetSkell staffDetSkell) 
	{
		// TODO Auto-generated method stub
		staffDetRepository.save(staffDetSkell);
	}

	@Override
	public StaffDetSkell getStaffById(String staffId) 
	{
		// TODO Auto-generated method stub
		StaffDetSkell staffDetSkell = staffDetRepository.getById(staffId);
		return staffDetSkell;
	}

	@Override
	public void updateStaffDet(StaffDetSkell staffDetSkell) 
	{
		// TODO Auto-generated method stub
		staffDetRepository.save(staffDetSkell);
	}

	@Override
	public List<StaffDetSkell> getAllStaff() 
	{
		// TODO Auto-generated method stub
		List<StaffDetSkell> staffDetSkellList = staffDetRepository.findAll();
		return staffDetSkellList;
	}

	@Override
	public void deleteStaffDet(String staffId) 
	{
		// TODO Auto-generated method stub
		staffDetRepository.deleteById(staffId);
	}

}
